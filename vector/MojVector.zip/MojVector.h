//Mateusz Jachna
#ifndef VECTOR
#define VECTOR
#include <iostream>
#include <stdexcept>

using namespace std;
class Vector{
   int wymiar;
   double *wsp;
public:
   class InvalidSize : public std::runtime_error{
      public:
      InvalidSize(const std::string msg = ""):std::runtime_error(msg){}
      const char* what() const throw()
      {
         return "Invalid size in Vector!";
      }
   };
   class IncompatibleDimensions : public std::logic_error{
   public:
      IncompatibleDimensions(const std::string msg = ""):std::logic_error(msg){}
      const char* what() const throw()
      {
         return "Incompatible dimensions!";
      }
   };
   Vector(int wym=1){
      if(wym<0) throw InvalidSize();
      wymiar = wym;
      wsp = new double[wym];
      for(int i=0;i<wym;i++)
         wsp[i]=0;
   }
   Vector(int wym, double *tab){
      if(wym<0) throw InvalidSize();
      wymiar = wym;
      wsp = new double[wym];
      for(int i=0;i<wym;i++)
         wsp[i]=tab[i];
   }
   Vector(int wym, int *tab){
      if(wym<0) throw InvalidSize();
      wymiar = wym;
      wsp = new double[wym];
      for(int i=0;i<wym;i++)
         wsp[i]=tab[i];
   }
   Vector(const Vector &v){
      if(v.wymiar<0) throw InvalidSize();
      wsp = new double [v.getSize()];
      wymiar = v.getSize();
      for(int i=0;i<wymiar;i++)
         wsp[i] = v.wsp[i];
   }
   ~Vector(){
      if(wymiar!=0){
         delete[] wsp;
         wymiar = 0;
      }
   }
   Vector operator=(const Vector v){
      wsp = (double*) realloc(wsp,v.wymiar*sizeof(double));
      wymiar = v.wymiar;
      for(int i=0;i<wymiar;i++)
         wsp[i] = v.wsp[i];
      return *this;
   }
   int getSize() const
   {
      return wymiar;
   }
   void clear (){
      for(int i=0;i<wymiar;i++)
         wsp[i]=0;
   }
   double& operator[](int index) const {
      return wsp[index];
   }
   friend const Vector operator+(const Vector&, const Vector&);

   friend const double operator*(const Vector&, const Vector&);
   friend const Vector operator*(const double&, const Vector&);
   friend const Vector operator*(const Vector&, const double&);

   friend const Vector operator-(const Vector&, const Vector&);
   friend const Vector operator-(Vector);

   friend std::ostream& operator<<(std::ostream&,Vector const&);
};
const Vector operator+(const Vector &v1,const Vector &v2){
   if(v1.wymiar!=v2.wymiar) throw Vector::IncompatibleDimensions();
   double *tmp = new double[v1.getSize()];
   for(int i=v1.wymiar-1;i>=0;i--){
      tmp[i] = v1.wsp[i]+v2.wsp[i];
   }
   return Vector(v1.wymiar,tmp);
}
const double operator*(const Vector& v1, const Vector& v2){
   /// iloczyn skalarny
   if(v1.wymiar!=v2.wymiar) throw Vector::IncompatibleDimensions();
   double tmp=0;
   for(int i=0;i<v1.wymiar;i++)
   {
      tmp += v1.wsp[i]*v2.wsp[i];
   }
   return tmp;
}

const Vector operator*(const Vector& v1, const double& d){
   double *tmp = new double[v1.wymiar];
   for(int i=0;i<v1.wymiar;i++){
      tmp[i] = v1.wsp[i]*d;
   }
   return Vector(v1.wymiar,tmp);
}

const Vector operator*(const double& d,const Vector& v1){
   double *tmp = new double[v1.wymiar];
   for(int i=0;i<v1.wymiar;i++){
      tmp[i] = v1.wsp[i]*d;
   }
   return Vector(v1.wymiar,tmp);
}
const Vector operator-(const Vector& v1, const Vector& v2){
   if(v1.wymiar!=v2.wymiar) throw Vector::IncompatibleDimensions();
   double *tmp = new double[v1.wymiar];
   for(int i=0;i<v1.wymiar;i++){
      tmp[i]=v1.wsp[i]-v2.wsp[i];
   }
   return Vector(v1.wymiar,tmp);
}
const Vector operator-(Vector v1){
   for(int i=0;i<v1.wymiar;i++){
      v1.wsp[i]= (-1.0)* v1.wsp[i];
   }
   return v1;
}
std::ostream& operator<<(std::ostream& wyjscie,Vector const &v){
   wyjscie <<"(";
   for(int i=0;i<v.wymiar;i++)
   {
      wyjscie<<v.wsp[i];
      if(i+1!=v.wymiar) wyjscie<<",";
   }
   wyjscie<<")";
   return wyjscie;
}

#endif
